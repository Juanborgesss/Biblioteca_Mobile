package com.example.bibliotecamobile;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class LivroDAO {
    private BancoHelper bancoHelper;

    public LivroDAO(Context context) {
        bancoHelper = new BancoHelper(context);
    }

    public void inserirLivro(String titulo) {
        SQLiteDatabase db = bancoHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("titulo", titulo);
        db.insert("livros", null, values);
        db.close();
    }

    public List<String> listarLivros() {
        List<String> livros = new ArrayList<>();
        SQLiteDatabase db = bancoHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT titulo FROM livros", null);

        if (cursor.moveToFirst()) {
            do {
                livros.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return livros;
    }
}
