package com.example.bibliotecamobile;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.snackbar.Snackbar;

public class PreferenciasActivity extends AppCompatActivity {

    CheckBox cbNotificacao, cbEmail, cbSomNotificacao;
    Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferencias);

        cbNotificacao = findViewById(R.id.cbNotificacao);
        cbEmail = findViewById(R.id.cbEmail);
        cbSomNotificacao = findViewById(R.id.cbSomNotificacao);
        btnSalvar = findViewById(R.id.btnSalvarPreferencias);

        // Carrega preferências salvas
        SharedPreferences prefs = getSharedPreferences("preferencias_usuario", MODE_PRIVATE);
        cbNotificacao.setChecked(prefs.getBoolean("notificacao", false));
        cbEmail.setChecked(prefs.getBoolean("email", false));
        cbSomNotificacao.setChecked(prefs.getBoolean("som_notificacao", false));

        btnSalvar.setOnClickListener(view -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("notificacao", cbNotificacao.isChecked());
            editor.putBoolean("email", cbEmail.isChecked());
            editor.putBoolean("som_notificacao", cbSomNotificacao.isChecked());
            editor.apply();

            // visual
            Snackbar snackbar = Snackbar.make(view, "Preferências salvas com sucesso!", Snackbar.LENGTH_SHORT);
            snackbar.setBackgroundTint(getResources().getColor(android.R.color.holo_green_dark));
            snackbar.setTextColor(getResources().getColor(android.R.color.white));
            snackbar.show();
        });
    }
}
