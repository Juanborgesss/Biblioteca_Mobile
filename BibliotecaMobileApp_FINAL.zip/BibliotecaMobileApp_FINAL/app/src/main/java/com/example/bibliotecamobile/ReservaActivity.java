package com.example.bibliotecamobile;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.snackbar.Snackbar;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ReservaActivity extends AppCompatActivity {

    private Spinner spinnerLivros;
    private EditText etLivroManual, etData;
    private Button btnReservar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserva);

        spinnerLivros = findViewById(R.id.spinnerLivros);
        etLivroManual = findViewById(R.id.etLivroManual);
        etData = findViewById(R.id.etData);
        btnReservar = findViewById(R.id.btnReservar);

        String[] livros = new String[]{
                "Selecione um livro...", "Livro 1", "Livro 2", "Livro 3", "Livro 4", "Livro 5"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, livros);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerLivros.setAdapter(adapter);

        // Formatação da data no campo EditText (dd/MM/yyyy)
        etData.addTextChangedListener(new TextWatcher() {
            private String current = "";
            private final String ddmmyyyy = "DDMMYYYY";
            private final Calendar cal = Calendar.getInstance();

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().equals(current)) {
                    String clean = s.toString().replaceAll("[^\\d]", "");
                    String cleanC = current.replaceAll("[^\\d]", "");

                    int cl = clean.length();
                    int sel = cl;
                    for (int i = 2; i <= cl && i < 6; i += 2) {
                        sel++;
                    }

                    if (clean.equals(cleanC)) sel--;

                    if (clean.length() < 8) {
                        clean = clean + ddmmyyyy.substring(clean.length());
                    } else {
                        int day  = Integer.parseInt(clean.substring(0, 2));
                        int mon  = Integer.parseInt(clean.substring(2, 4));
                        int year = Integer.parseInt(clean.substring(4, 8));

                        mon = (mon < 1) ? 1 : Math.min(mon, 12);
                        cal.set(Calendar.MONTH, mon - 1);
                        cal.set(Calendar.YEAR, year);
                        day = Math.min(day, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
                        clean = String.format("%02d%02d%04d", day, mon, year);
                    }

                    clean = String.format("%s/%s/%s", clean.substring(0, 2),
                            clean.substring(2, 4),
                            clean.substring(4, 8));

                    sel = Math.max(0, Math.min(sel, clean.length()));
                    current = clean;
                    etData.removeTextChangedListener(this);
                    etData.setText(clean);
                    etData.setSelection(sel);
                    etData.addTextChangedListener(this);
                }
            }
        });

        btnReservar.setOnClickListener(view -> {
            String livroSelecionado = spinnerLivros.getSelectedItem().toString();
            String livroDigitado = etLivroManual.getText().toString().trim();
            String data = etData.getText().toString().trim();

            if (TextUtils.isEmpty(livroDigitado) && livroSelecionado.equals("Selecione um livro...")) {
                mostrarSnackbar(view, "Informe ou selecione o nome do livro.");
                return;
            }

            if (TextUtils.isEmpty(data)) {
                mostrarSnackbar(view, "Informe a data da reserva.");
                return;
            }


            String dataNumerica = data.replaceAll("[^\\d]", "");

            // Validar se todos os dígitos são iguais
            if (todosDigitosIguais(dataNumerica)) {
                mostrarSnackbar(view, "Data inválida.");
                return;
            }


            if (!dataValida(data)) {
                mostrarSnackbar(view, "Data inexistente.");
                return;
            }

            String livroFinal = !TextUtils.isEmpty(livroDigitado) ? livroDigitado : livroSelecionado;
            String mensagem = "Livro \"" + livroFinal + "\" reservado para " + data;

            Snackbar snackbar = Snackbar.make(view, mensagem, Snackbar.LENGTH_LONG)
                    .setAction("X", v -> resetarFormulario());
            snackbar.setBackgroundTint(getResources().getColor(android.R.color.holo_green_dark));
            snackbar.setTextColor(getResources().getColor(android.R.color.white));
            snackbar.setActionTextColor(getResources().getColor(android.R.color.white));
            snackbar.show();
        });
    }

    private void resetarFormulario() {
        spinnerLivros.setSelection(0);
        etLivroManual.setText("");
        etData.setText("");
    }

    private void mostrarSnackbar(View view, String texto) {
        Snackbar snackbar = Snackbar.make(view, texto, Snackbar.LENGTH_SHORT);
        snackbar.setBackgroundTint(getResources().getColor(android.R.color.holo_red_dark));
        snackbar.setTextColor(getResources().getColor(android.R.color.white));
        snackbar.show();
    }

    // dígitos da string são iguais
    private boolean todosDigitosIguais(String s) {
        if (s.isEmpty()) return false;
        char primeiro = s.charAt(0);
        for (int i = 1; i < s.length(); i++) {
            if (s.charAt(i) != primeiro) return false;
        }
        return true;
    }

    //data é válida
    private boolean dataValida(String data) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        sdf.setLenient(false);
        try {
            Date d = sdf.parse(data);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }
}
