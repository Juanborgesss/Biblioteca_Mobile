package com.example.bibliotecamobile;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {

    private EditText edtNovoUsuario, edtNovaSenha;
    private Button btnRegistrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        edtNovoUsuario = findViewById(R.id.edtNovoUsuario);
        edtNovaSenha = findViewById(R.id.edtNovaSenha);
        btnRegistrar = findViewById(R.id.btnRegistrar);

        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registrarUsuario();
            }
        });
    }

    private void registrarUsuario() {
        String usuario = edtNovoUsuario.getText().toString().trim();
        String senha = edtNovaSenha.getText().toString().trim();

        if (usuario.isEmpty() || senha.isEmpty()) {
            Toast.makeText(this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        // SharedPreferences
        SharedPreferences prefs = getSharedPreferences("Usuarios", Context.MODE_PRIVATE);

        if (prefs.contains(usuario)) {
            Toast.makeText(this, "Usuário já existe. Escolha outro nome.", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(usuario, senha);
        editor.apply();

        Toast.makeText(this, "Usuário registrado com sucesso!", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
