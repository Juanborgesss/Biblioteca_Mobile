package com.example.bibliotecamobile;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class LeituraActivity extends AppCompatActivity {

    private TextView textoLeitura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leitura);

        textoLeitura = findViewById(R.id.textoLeitura);

        //simular a leitura
        String titulo = getIntent().getStringExtra("tituloLivro");
        if (titulo != null) {
            textoLeitura.setText("Você está lendo o livro: " + titulo);
        }
    }
}
