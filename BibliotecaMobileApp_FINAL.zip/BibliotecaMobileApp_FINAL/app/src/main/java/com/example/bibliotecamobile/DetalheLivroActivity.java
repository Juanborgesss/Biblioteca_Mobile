package com.example.bibliotecamobile;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetalheLivroActivity extends AppCompatActivity {

    private TextView tituloLivro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhe_livro);

        tituloLivro = findViewById(R.id.tituloLivro);

        String titulo = getIntent().getStringExtra("tituloLivro");
        if (titulo != null) {
            tituloLivro.setText(titulo);
        }
    }
}
