package com.example.bibliotecamobile;

import android.content.Intent;
import android.os.Bundle;
import android.widget.GridLayout;
import android.widget.Toast;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class ConsultaActivity extends AppCompatActivity {

    private GridLayout gridLivros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consulta);

        gridLivros = findViewById(R.id.gridLivros);

        int count = gridLivros.getChildCount();
        for (int i = 0; i < count; i++) {
            View livroView = gridLivros.getChildAt(i);
            final int index = i + 1;
            livroView.setOnClickListener(v -> {
                Toast.makeText(this, "Você selecionou o Livro " + index, Toast.LENGTH_SHORT).show();

                // Abrir a LeituraActivity
                Intent intent = new Intent(ConsultaActivity.this, LeituraActivity.class);
                intent.putExtra("tituloLivro", "Livro " + index);
                startActivity(intent);
            });
        }
    }
}
