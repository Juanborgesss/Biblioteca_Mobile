package com.example.bibliotecamobile;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RenovacaoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_renovacao);

        Button btnRenovar = findViewById(R.id.btnRenovar);
        TextView textView = findViewById(R.id.txtMensagemRenovacao);

        btnRenovar.setOnClickListener(v -> {
            textView.setText("Empréstimo renovado com sucesso até 20/06/2025!");
            Toast.makeText(this, "Renovação confirmada!", Toast.LENGTH_SHORT).show();
        });
    }
}
