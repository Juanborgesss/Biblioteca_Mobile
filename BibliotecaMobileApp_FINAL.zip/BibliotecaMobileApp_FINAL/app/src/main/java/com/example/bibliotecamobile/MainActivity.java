package com.example.bibliotecamobile;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvBemVindo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvBemVindo = findViewById(R.id.tvBemVindo);

        SharedPreferences loginPrefs = getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE);
        String nomeUsuario = loginPrefs.getString("usuarioLogado", "Usuário");

        tvBemVindo.setText("Bem-vindo, " + nomeUsuario);

        Button btnConsulta = findViewById(R.id.btnConsulta);
        Button btnReserva = findViewById(R.id.btnReserva);
        Button btnRenovacao = findViewById(R.id.btnRenovacao);
        Button btnPreferencias = findViewById(R.id.btnPreferencias);

        btnConsulta.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ConsultaActivity.class))
        );

        btnReserva.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ReservaActivity.class))
        );

        btnRenovacao.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, RenovacaoActivity.class))
        );

        btnPreferencias.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, PreferenciasActivity.class))
        );

        for (int i = 1; i <= 15; i++) {
            int resID = getResources().getIdentifier("livro" + i, "id", getPackageName());
            LinearLayout livroLayout = findViewById(resID);
            final int livroNumero = i;
            if (livroLayout != null) {
                livroLayout.setOnClickListener(v -> {
                    Intent intent = new Intent(MainActivity.this, DetalheLivroActivity.class);
                    intent.putExtra("numero_livro", livroNumero);
                    startActivity(intent);
                });
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_logout) {
            SharedPreferences loginPrefs = getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE);
            loginPrefs.edit().remove("usuarioLogado").apply();

            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
