package com.example.bibliotecamobile;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.test.core.app.ApplicationProvider;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class DatabaseTest {

    private BancoHelper dbHelper;

    @Before
    public void setUp() {
        Context context = ApplicationProvider.getApplicationContext();
        dbHelper = new BancoHelper(context);
    }

    @Test
    public void testInsertAndQueryLivro() {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("INSERT INTO livros (titulo) VALUES ('Test Book')");
        Cursor cursor = db.rawQuery("SELECT * FROM livros WHERE titulo = 'Test Book'", null);
        assertTrue(cursor.moveToFirst());
        cursor.close();
        db.close();
    }
}